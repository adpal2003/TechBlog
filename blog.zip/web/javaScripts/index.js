function doLike(pid, uid) {
    console.log(pid + "," + uid);
    const data = {
        uid: uid,
        pid: pid,
        operation: 'like'
    };

    $.ajax({
        url: "LikeServlet",
        method: "POST", // Assuming you want to use the POST method, adjust if necessary
        data: data,
        success: function (data,textStatus,jqXHR) {
            console.log(data);
        },   
        error: function (jqXHR, textStatus, errorThrown) {
            console.log(data);
        }
    });
}
